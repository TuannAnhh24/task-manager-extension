// UI layer for the fullpage tab: sidebar filters, drag-and-drop board and
// the create/edit panel. Wires the DOM to the storage.js data layer.
import {
  PRIORITY_ORDER,
  getAllTasks,
  getVisibleTasks,
  createTask,
  updateTask,
  cycleTaskStatus,
  getTodayDoneTasks,
  getAllDoneTasks,
  deleteTask,
  reorderTasks,
  getProjectTags,
  getSettingsProjectTags,
  saveSettingsProjectTags,
  getSettingsTaskTypes,
  saveSettingsTaskTypes,
  getStorageUsage,
  onTasksChanged,
} from './storage.js';
import { createTagCombo } from './tag-combo.js';

/** Short "dd/MM" date, e.g. "02/07". */
function formatDateShort(isoString) {
  const date = new Date(isoString);
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  return `${day}/${month}`;
}

/** "HH:mm" time from a timestamp, e.g. "14:32". */
function formatTime(timestamp) {
  const date = new Date(timestamp);
  const h = String(date.getHours()).padStart(2, '0');
  const m = String(date.getMinutes()).padStart(2, '0');
  return `${h}:${m}`;
}

/** "dd/MM/yyyy" for the Today tab header. */
function formatDateFull(timestamp) {
  const date = new Date(timestamp);
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  return `${day}/${month}/${date.getFullYear()}`;
}

const PRIORITY_LABELS = {
  now: 'Làm ngay',
  schedule: 'Lên lịch',
  delegate: 'Tiện thì làm',
  drop: 'Có thể bỏ',
};

const PRIORITY_COLOR_VAR = {
  now: '--priority-now',
  schedule: '--priority-schedule',
  delegate: '--priority-delegate',
  drop: '--priority-drop',
};

// Task types are configured in Settings; look up label by value.
let taskTypes = [];
function typeLabel(value) {
  const match = taskTypes.find((t) => t.value === value);
  return match ? match.label : value;
}

let allTasks = [];
let todayDoneTasks = [];
let allDoneTasks = [];
let projectTags = [];
let activeTagFilter = 'all';
let activeTypeFilter = 'all';
let searchQuery = '';
let activeTab = 'all';
let editingTaskId = null;

let dragState = null;

const boardEl = document.getElementById('task-board');
const tagFilterListEl = document.getElementById('tag-filter-list');
const typeFilterListEl = document.getElementById('type-filter-list');
const searchInput = document.getElementById('search-input');
const addTaskBtn = document.getElementById('add-task-btn');
const tabSwitcher = document.getElementById('tab-switcher');

const editOverlay = document.getElementById('edit-overlay');
const editPanelTitle = document.getElementById('edit-panel-title');
const editTitleInput = document.getElementById('edit-title');
const editNoteInput = document.getElementById('edit-note');
const editPriorityGroup = document.getElementById('edit-priority');
const editTypeGroup = document.getElementById('edit-type');
const editTagComboEl = document.getElementById('edit-tag-combo');
const editSaveBtn = document.getElementById('edit-save');
const editDeleteBtn = document.getElementById('edit-delete');

let editPriorityValue = 'now';
let editTypeValue = 'other';

const editTagCombo = createTagCombo({
  container: editTagComboEl,
  getTags: () => projectTags,
  onChange: () => {},
});

function renderIcons() {
  if (window.lucide) window.lucide.createIcons();
}

async function loadData() {
  const [tasks, tags, todayDone, allDone, types] = await Promise.all([
    getVisibleTasks(),
    getProjectTags(),
    getTodayDoneTasks(),
    getAllDoneTasks(),
    getSettingsTaskTypes(),
  ]);
  allTasks = tasks;
  projectTags = tags;
  todayDoneTasks = todayDone;
  allDoneTasks = allDone;
  taskTypes = types;
  renderEditTypePills();
  renderSidebar();
  render();
  renderStorageUsage();
}

/** Update the sidebar storage bar/text and the over-quota warning banner. */
async function renderStorageUsage() {
  const { usedKB, totalKB, percent } = await getStorageUsage();

  const fill = document.getElementById('storage-bar-fill');
  const text = document.getElementById('storage-text');
  if (fill) {
    fill.style.width = `${percent}%`;
    fill.classList.remove('warning', 'danger');
    if (percent > 90) fill.classList.add('danger');
    else if (percent > 70) fill.classList.add('warning');
  }
  if (text) {
    text.textContent = `${usedKB} KB / ${totalKB} KB (${percent}%)`;
  }

  let message = null;
  if (percent > 90) message = 'Dung lượng gần đầy (>90%). Nên xóa bớt task cũ.';
  else if (percent > 70) message = 'Dung lượng đã dùng >70%.';
  updateStorageWarning(message);
}

/** Show/replace/remove the warning banner at the top of the task board. */
function updateStorageWarning(message) {
  const existing = document.getElementById('storage-warning');
  if (existing) existing.remove();
  if (!message) return;

  const banner = document.createElement('div');
  banner.id = 'storage-warning';
  banner.className = 'storage-warning';
  const icon = document.createElement('i');
  icon.setAttribute('data-lucide', 'alert-triangle');
  banner.appendChild(icon);
  banner.appendChild(document.createTextNode(message));
  boardEl.insertBefore(banner, boardEl.firstChild);
  renderIcons();
}

/** Dispatch to the active tab's view. */
function render() {
  if (activeTab === 'today') {
    renderTodayView();
  } else if (activeTab === 'history') {
    renderHistoryView();
  } else {
    renderBoard();
  }
}

function renderSidebar() {
  tagFilterListEl.replaceChildren();
  const allTagBtn = document.createElement('button');
  allTagBtn.className = 'sidebar__item' + (activeTagFilter === 'all' ? ' is-active' : '');
  allTagBtn.textContent = 'Tất cả';
  allTagBtn.addEventListener('click', () => {
    activeTagFilter = 'all';
    renderSidebar();
    renderBoard();
  });
  tagFilterListEl.appendChild(allTagBtn);

  for (const tag of projectTags) {
    const btn = document.createElement('button');
    btn.className = 'sidebar__item' + (activeTagFilter === tag ? ' is-active' : '');
    btn.textContent = tag;
    btn.addEventListener('click', () => {
      activeTagFilter = tag;
      renderSidebar();
      renderBoard();
    });
    tagFilterListEl.appendChild(btn);
  }

  typeFilterListEl.replaceChildren();
  const allTypeBtn = document.createElement('button');
  allTypeBtn.className = 'sidebar__item' + (activeTypeFilter === 'all' ? ' is-active' : '');
  allTypeBtn.textContent = 'Tất cả';
  allTypeBtn.addEventListener('click', () => {
    activeTypeFilter = 'all';
    renderSidebar();
    renderBoard();
  });
  typeFilterListEl.appendChild(allTypeBtn);

  for (const type of taskTypes) {
    const btn = document.createElement('button');
    btn.className = 'sidebar__item' + (activeTypeFilter === type.value ? ' is-active' : '');
    btn.textContent = type.label;
    btn.addEventListener('click', () => {
      activeTypeFilter = type.value;
      renderSidebar();
      renderBoard();
    });
    typeFilterListEl.appendChild(btn);
  }
}

function filteredTasks() {
  const query = searchQuery.trim().toLowerCase();
  return allTasks.filter((task) => {
    if (activeTagFilter !== 'all' && task.project_tag !== activeTagFilter) return false;
    if (activeTypeFilter !== 'all' && task.type !== activeTypeFilter) return false;
    if (query) {
      const haystack = `${task.title} ${task.note} ${task.project_tag}`.toLowerCase();
      if (!haystack.includes(query)) return false;
    }
    return true;
  });
}

function makeCheckIconSvg() {
  const svgNS = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(svgNS, 'svg');
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('fill', 'none');
  svg.setAttribute('stroke', 'currentColor');
  svg.setAttribute('stroke-width', '3');
  svg.setAttribute('stroke-linecap', 'round');
  svg.setAttribute('stroke-linejoin', 'round');
  const path = document.createElementNS(svgNS, 'path');
  path.setAttribute('d', 'M20 6 9 17l-5-5');
  svg.appendChild(path);
  return svg;
}

function buildTaskRow(task, { draggable }) {
  const row = document.createElement('div');
  row.className = 'task-row' + (task.status === 'done' ? ' is-done' : '');
  row.dataset.id = task.id;
  row.dataset.priority = task.priority;

  const handle = document.createElement('span');
  handle.className = 'drag-handle' + (draggable ? '' : ' is-disabled');
  const handleIcon = document.createElement('i');
  handleIcon.setAttribute('data-lucide', 'grip-vertical');
  handle.appendChild(handleIcon);
  row.appendChild(handle);

  const checkbox = document.createElement('button');
  let checkboxCls = 'checkbox';
  if (task.status === 'done') checkboxCls += ' is-checked';
  else if (task.status === 'in_progress') checkboxCls += ' is-progress';
  checkbox.className = checkboxCls;
  checkbox.setAttribute('aria-label', 'Đổi trạng thái task');
  checkbox.appendChild(makeCheckIconSvg());
  checkbox.addEventListener('click', async (e) => {
    e.stopPropagation();
    // Cycle: todo -> in_progress -> done -> todo.
    await cycleTaskStatus(task.id);
    await loadData();
  });
  row.appendChild(checkbox);

  const title = document.createElement('span');
  title.className = 'task-row__title';
  title.textContent = task.title;
  row.appendChild(title);

  if (task.status === 'in_progress') {
    const progressBadge = document.createElement('span');
    progressBadge.className = 'badge-progress';
    progressBadge.textContent = 'Đang làm';
    row.appendChild(progressBadge);
  }

  const badgeGroup = document.createElement('div');
  badgeGroup.className = 'badge-group';

  const typeBadge = document.createElement('span');
  typeBadge.className = 'badge';
  typeBadge.textContent = typeLabel(task.type);
  badgeGroup.appendChild(typeBadge);

  if (task.project_tag) {
    const tagBadge = document.createElement('span');
    tagBadge.className = 'badge badge-tag';
    const tagIcon = document.createElement('i');
    tagIcon.setAttribute('data-lucide', 'tag');
    tagBadge.appendChild(tagIcon);
    tagBadge.appendChild(document.createTextNode(task.project_tag));
    badgeGroup.appendChild(tagBadge);
  }

  row.appendChild(badgeGroup);

  const date = document.createElement('span');
  date.className = 'task-date';
  date.textContent = formatDateShort(task.created_at);
  row.appendChild(date);

  const actions = document.createElement('div');
  actions.className = 'task-actions';

  const editBtn = document.createElement('button');
  editBtn.className = 'icon-btn';
  editBtn.setAttribute('aria-label', 'Sửa task');
  const editIcon = document.createElement('i');
  editIcon.setAttribute('data-lucide', 'pencil');
  editBtn.appendChild(editIcon);
  editBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    openEditPanel(task);
  });
  actions.appendChild(editBtn);

  const deleteBtn = document.createElement('button');
  deleteBtn.className = 'icon-btn';
  deleteBtn.setAttribute('aria-label', 'Xóa task');
  const deleteIcon = document.createElement('i');
  deleteIcon.setAttribute('data-lucide', 'trash-2');
  deleteBtn.appendChild(deleteIcon);
  deleteBtn.addEventListener('click', async (e) => {
    e.stopPropagation();
    await deleteTask(task.id);
    await loadData();
  });
  actions.appendChild(deleteBtn);

  row.appendChild(actions);

  row.addEventListener('click', () => openEditPanel(task));

  if (draggable) {
    row.draggable = true;
    row.addEventListener('dragstart', (e) => {
      dragState = { id: task.id, priority: task.priority };
      row.classList.add('is-dragging');
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/plain', task.id);
    });
    row.addEventListener('dragend', () => {
      row.classList.remove('is-dragging');
      clearDropMarkers();
      dragState = null;
    });
    row.addEventListener('dragover', (e) => {
      if (!dragState || dragState.priority !== task.priority || dragState.id === task.id) return;
      e.preventDefault();
      const rect = row.getBoundingClientRect();
      const before = e.clientY - rect.top < rect.height / 2;
      clearDropMarkers();
      row.classList.add(before ? 'drop-before' : 'drop-after');
    });
    row.addEventListener('drop', async (e) => {
      if (!dragState || dragState.priority !== task.priority || dragState.id === task.id) return;
      e.preventDefault();
      const rect = row.getBoundingClientRect();
      const before = e.clientY - rect.top < rect.height / 2;
      await handleDrop(task.priority, dragState.id, task.id, before);
      clearDropMarkers();
    });
  }

  return row;
}

function clearDropMarkers() {
  for (const el of boardEl.querySelectorAll('.drop-before, .drop-after')) {
    el.classList.remove('drop-before', 'drop-after');
  }
}

async function handleDrop(priority, draggedId, targetId, before) {
  const groupIds = allTasks
    .filter((t) => t.priority === priority && t.status !== 'done')
    .map((t) => t.id);

  const withoutDragged = groupIds.filter((id) => id !== draggedId);
  const targetIndex = withoutDragged.indexOf(targetId);
  const insertIndex = before ? targetIndex : targetIndex + 1;
  withoutDragged.splice(insertIndex, 0, draggedId);

  await reorderTasks(priority, withoutDragged);
  await loadData();
}

function buildGroupEmptyState() {
  const wrap = document.createElement('div');
  wrap.className = 'empty-state-group';
  const icon = document.createElement('i');
  icon.setAttribute('data-lucide', 'minus');
  wrap.appendChild(icon);
  const text = document.createElement('span');
  text.textContent = 'Không có task nào';
  wrap.appendChild(text);
  return wrap;
}

function buildListEmptyState() {
  const wrap = document.createElement('div');
  wrap.className = 'empty-state-full';
  const icon = document.createElement('i');
  icon.setAttribute('data-lucide', 'clipboard-list');
  icon.className = 'empty-state-full__icon';
  wrap.appendChild(icon);
  const title = document.createElement('p');
  title.className = 'empty-title';
  title.textContent = 'Chưa có task nào';
  wrap.appendChild(title);
  const sub = document.createElement('p');
  sub.className = 'empty-sub';
  sub.textContent = 'Thêm task đầu tiên để bắt đầu';
  wrap.appendChild(sub);
  return wrap;
}

function renderBoard() {
  boardEl.classList.remove('is-today');
  boardEl.replaceChildren();
  const tasks = filteredTasks();

  // Nothing anywhere (empty storage or filter yields nothing): one big empty state.
  if (tasks.length === 0) {
    boardEl.appendChild(buildListEmptyState());
    renderIcons();
    return;
  }

  for (const priority of PRIORITY_ORDER) {
    // "Active" = not done (todo + in_progress); done tasks pinned below them.
    const activeTasks = tasks.filter((t) => t.priority === priority && t.status !== 'done');
    const doneTasks = tasks.filter((t) => t.priority === priority && t.status === 'done');

    const group = document.createElement('section');
    group.className = 'task-group';

    const header = document.createElement('div');
    header.className = 'task-group__header';
    header.style.color = `var(${PRIORITY_COLOR_VAR[priority]})`;
    const dot = document.createElement('span');
    dot.className = 'task-group__dot';
    dot.style.background = `var(${PRIORITY_COLOR_VAR[priority]})`;
    header.appendChild(dot);
    header.appendChild(document.createTextNode(PRIORITY_LABELS[priority]));
    const count = document.createElement('span');
    count.className = 'group-count';
    count.textContent = String(activeTasks.length);
    header.appendChild(count);
    group.appendChild(header);

    if (activeTasks.length === 0 && doneTasks.length === 0) {
      group.appendChild(buildGroupEmptyState());
    } else {
      for (const task of activeTasks) {
        group.appendChild(buildTaskRow(task, { draggable: true }));
      }
      for (const task of doneTasks) {
        group.appendChild(buildTaskRow(task, { draggable: false }));
      }
    }

    boardEl.appendChild(group);
  }

  renderIcons();
}

function renderTodayView() {
  boardEl.classList.add('is-today');
  boardEl.replaceChildren();

  if (todayDoneTasks.length === 0) {
    const wrap = document.createElement('div');
    wrap.className = 'empty-state-full';
    const icon = document.createElement('i');
    icon.setAttribute('data-lucide', 'coffee');
    icon.className = 'empty-state-full__icon';
    wrap.appendChild(icon);
    const title = document.createElement('p');
    title.className = 'empty-title';
    title.textContent = 'Chưa hoàn thành task nào hôm nay';
    wrap.appendChild(title);
    const sub = document.createElement('p');
    sub.className = 'empty-sub';
    sub.textContent = 'Bắt đầu tick done task đầu tiên nào!';
    wrap.appendChild(sub);
    boardEl.appendChild(wrap);
    renderIcons();
    return;
  }

  const header = document.createElement('div');
  header.className = 'today-header';
  header.textContent = `Hôm nay, ${formatDateFull(Date.now())}`;
  boardEl.appendChild(header);

  for (const task of todayDoneTasks) {
    const row = document.createElement('div');
    row.className = 'today-task-row';

    const check = document.createElement('i');
    check.setAttribute('data-lucide', 'check-circle-2');
    check.className = 'today-check-icon';
    row.appendChild(check);

    const name = document.createElement('span');
    name.className = 'today-task-name';
    name.textContent = task.title;
    row.appendChild(name);

    const time = document.createElement('span');
    time.className = 'today-done-time';
    time.textContent = formatTime(task.done_at);
    row.appendChild(time);

    const badge = document.createElement('span');
    badge.className = 'today-badge';
    badge.textContent = typeLabel(task.type);
    row.appendChild(badge);

    boardEl.appendChild(row);
  }

  const summary = document.createElement('div');
  summary.className = 'today-summary';
  summary.textContent = `Tổng: ${todayDoneTasks.length} task hoàn thành`;
  boardEl.appendChild(summary);

  renderIcons();
}

// --- History tab ---

/** Local "YYYY-MM-DD" key for grouping by completion day. */
function dayKeyOf(timestamp) {
  const d = new Date(timestamp);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

async function deleteHistoryTask(taskId) {
  await deleteTask(taskId);
  await loadData(); // re-renders the current (history) view + storage bar
}

async function deleteHistoryDay(dayKey) {
  const ids = allDoneTasks
    .filter((t) => t.done_at && dayKeyOf(t.done_at) === dayKey)
    .map((t) => t.id);
  for (const id of ids) {
    await deleteTask(id);
  }
  await loadData();
}

function renderHistoryView() {
  boardEl.classList.remove('is-today');
  boardEl.replaceChildren();

  if (allDoneTasks.length === 0) {
    const wrap = document.createElement('div');
    wrap.className = 'empty-state-full';
    const icon = document.createElement('i');
    icon.setAttribute('data-lucide', 'history');
    icon.className = 'empty-state-full__icon';
    wrap.appendChild(icon);
    const title = document.createElement('p');
    title.className = 'empty-title';
    title.textContent = 'Chưa có lịch sử';
    wrap.appendChild(title);
    const sub = document.createElement('p');
    sub.className = 'empty-sub';
    sub.textContent = 'Các task hoàn thành sẽ xuất hiện ở đây';
    wrap.appendChild(sub);
    boardEl.appendChild(wrap);
    renderIcons();
    return;
  }

  // Group by day, preserving the newest-first order of allDoneTasks.
  const groups = new Map();
  for (const task of allDoneTasks) {
    const key = dayKeyOf(task.done_at);
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(task);
  }

  for (const [dayKey, tasks] of groups) {
    const section = document.createElement('section');
    section.className = 'history-section';

    const header = document.createElement('div');
    header.className = 'history-date-header';

    const label = document.createElement('span');
    label.className = 'history-date-label';
    label.textContent = formatDateFull(tasks[0].done_at);
    header.appendChild(label);

    const cnt = document.createElement('span');
    cnt.className = 'history-date-count';
    cnt.textContent = `(${tasks.length} task)`;
    header.appendChild(cnt);

    const line = document.createElement('div');
    line.className = 'history-date-line';
    header.appendChild(line);

    const delDayBtn = document.createElement('button');
    delDayBtn.className = 'history-delete-day-btn';
    delDayBtn.textContent = 'Xóa ngày này';
    delDayBtn.addEventListener('click', async () => {
      if (!confirm(`Xóa tất cả ${tasks.length} task hoàn thành ngày ${label.textContent}?`)) return;
      await deleteHistoryDay(dayKey);
    });
    header.appendChild(delDayBtn);

    section.appendChild(header);

    for (const task of tasks) {
      section.appendChild(buildHistoryRow(task));
    }

    boardEl.appendChild(section);
  }

  renderIcons();
}

function buildHistoryRow(task) {
  const row = document.createElement('div');
  row.className = 'history-task-row';

  const check = document.createElement('i');
  check.setAttribute('data-lucide', 'check');
  check.className = 'history-check';
  row.appendChild(check);

  const name = document.createElement('span');
  name.className = 'history-task-name';
  name.textContent = task.title;
  row.appendChild(name);

  const time = document.createElement('span');
  time.className = 'history-time';
  time.textContent = task.done_at ? formatTime(task.done_at) : '';
  row.appendChild(time);

  const badge = document.createElement('span');
  badge.className = 'history-badge';
  badge.textContent = typeLabel(task.type);
  row.appendChild(badge);

  if (task.project_tag) {
    const tag = document.createElement('span');
    tag.className = 'history-tag';
    tag.textContent = task.project_tag;
    row.appendChild(tag);
  }

  const delBtn = document.createElement('button');
  delBtn.className = 'history-delete-btn';
  delBtn.setAttribute('aria-label', 'Xóa task');
  const delIcon = document.createElement('i');
  delIcon.setAttribute('data-lucide', 'trash-2');
  delBtn.appendChild(delIcon);
  delBtn.addEventListener('click', async () => {
    await deleteHistoryTask(task.id);
  });
  row.appendChild(delBtn);

  return row;
}

/** Render the type pills in the edit panel from the current settings types. */
function renderEditTypePills() {
  editTypeGroup.replaceChildren();
  for (const type of taskTypes) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'type-pill' + (type.value === editTypeValue ? ' is-active' : '');
    btn.dataset.type = type.value;
    btn.textContent = type.label;
    editTypeGroup.appendChild(btn);
  }
}

// --- Search ---
searchInput.addEventListener('input', () => {
  searchQuery = searchInput.value;
  // Searching implies browsing all tasks, not the Today summary.
  if (searchQuery && activeTab !== 'all') setActiveTab('all');
  else render();
});

// --- Tab switcher ---
function setActiveTab(tab) {
  activeTab = tab;
  for (const btn of tabSwitcher.querySelectorAll('.tab-btn')) {
    btn.classList.toggle('is-active', btn.dataset.tab === tab);
  }
  render();
}

tabSwitcher.addEventListener('click', (e) => {
  const btn = e.target.closest('.tab-btn');
  if (!btn) return;
  setActiveTab(btn.dataset.tab);
});

// --- Edit panel ---

function setActivePill(group, value, dataAttr) {
  for (const pill of group.querySelectorAll('button')) {
    pill.classList.toggle('is-active', pill.dataset[dataAttr] === value);
  }
}

editPriorityGroup.addEventListener('click', (e) => {
  const btn = e.target.closest('[data-priority]');
  if (!btn) return;
  editPriorityValue = btn.dataset.priority;
  setActivePill(editPriorityGroup, editPriorityValue, 'priority');
});

editTypeGroup.addEventListener('click', (e) => {
  const btn = e.target.closest('[data-type]');
  if (!btn) return;
  editTypeValue = btn.dataset.type;
  setActivePill(editTypeGroup, editTypeValue, 'type');
});

function openEditPanel(task) {
  editingTaskId = task ? task.id : null;
  editPanelTitle.textContent = task ? 'Chỉnh sửa task' : 'Thêm task mới';
  editTitleInput.value = task ? task.title : '';
  editNoteInput.value = task ? task.note : '';
  editPriorityValue = task ? task.priority : 'now';
  editTypeValue = task ? task.type : 'other';
  editTagCombo.setValue(task ? task.project_tag : '');
  editDeleteBtn.hidden = !task;

  setActivePill(editPriorityGroup, editPriorityValue, 'priority');
  setActivePill(editTypeGroup, editTypeValue, 'type');

  editOverlay.hidden = false;
  editTitleInput.focus();
}

function closeEditPanel() {
  editOverlay.hidden = true;
  editingTaskId = null;
  // Clear the form so stale data never leaks into the next open.
  editTitleInput.value = '';
  editNoteInput.value = '';
  editTagCombo.setValue('');
}

// Delegated on the overlay (never re-rendered) rather than the close button
// directly, so the handler can't be lost if the panel markup ever changes.
editOverlay.addEventListener('click', (e) => {
  if (e.target === editOverlay || e.target.closest('#edit-panel-close')) {
    closeEditPanel();
  }
});

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && !editOverlay.hidden) closeEditPanel();
});

editSaveBtn.addEventListener('click', async () => {
  const title = editTitleInput.value.trim();
  if (!title) {
    editTitleInput.focus();
    return;
  }
  const payload = {
    title,
    note: editNoteInput.value.trim(),
    priority: editPriorityValue,
    type: editTypeValue,
    project_tag: editTagCombo.getValue(),
  };
  if (editingTaskId) {
    await updateTask(editingTaskId, payload);
  } else {
    await createTask(payload);
  }
  closeEditPanel();
  await loadData();
});

editDeleteBtn.addEventListener('click', async () => {
  if (!editingTaskId) return;
  if (!confirm('Xóa task này?')) return;
  await deleteTask(editingTaskId);
  closeEditPanel();
  await loadData();
});

addTaskBtn.addEventListener('click', () => openEditPanel(null));

// --- Settings modal ---

const settingsBtn = document.getElementById('btn-settings');
const settingsOverlay = document.getElementById('settings-overlay');
const settingsNav = document.getElementById('settings-nav');
const settingsContent = document.getElementById('settings-content');

let settingsPanel = 'tags'; // 'tags' | 'types'
let settingsTags = [];
let settingsTypesList = [];
// Inline edit/add state for the settings lists.
let editingTagIndex = -1;
let addingTag = false;
let editingTypeIndex = -1;
let addingType = false;

/** Slugify a label into a task-type value: "Thiết kế" -> "thiet_ke". */
function slugifyType(label) {
  const base = label
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/đ/g, 'd')
    .replace(/Đ/g, 'D')
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '');
  let value = base || 'type';
  const existing = new Set(settingsTypesList.map((t) => t.value));
  if (existing.has(value)) {
    let n = 2;
    while (existing.has(`${value}_${n}`)) n += 1;
    value = `${value}_${n}`;
  }
  return value;
}

async function openSettings() {
  settingsPanel = 'tags';
  editingTagIndex = -1;
  addingTag = false;
  editingTypeIndex = -1;
  addingType = false;
  settingsTags = await getSettingsProjectTags();
  settingsTypesList = await getSettingsTaskTypes();
  settingsOverlay.hidden = false;
  renderSettings();
}

function closeSettings() {
  settingsOverlay.hidden = true;
}

/** Refresh the rest of the app (dropdown, filters, badges, storage bar) after
 *  a settings change. loadData() re-renders everything and updates the bar. */
async function commitSettings() {
  await loadData();
}

function renderSettings() {
  // Nav active state
  for (const item of settingsNav.querySelectorAll('.settings-nav-item')) {
    item.classList.toggle('active', item.dataset.panel === settingsPanel);
  }
  if (settingsPanel === 'tags') renderTagsPanel();
  else renderTypesPanel();
  renderIcons();
}

function makeSettingsSectionTitle(text) {
  const el = document.createElement('div');
  el.className = 'settings-section-title';
  el.textContent = text;
  return el;
}

function makeAddButton(label, onClick) {
  const btn = document.createElement('button');
  btn.className = 'btn-add-new';
  const icon = document.createElement('i');
  icon.setAttribute('data-lucide', 'plus');
  btn.appendChild(icon);
  btn.appendChild(document.createTextNode(label));
  btn.addEventListener('click', onClick);
  return btn;
}

// Row with an inline text input + Lưu / Hủy buttons.
function makeEditRow(initialValue, onSave, onCancel) {
  const row = document.createElement('div');
  row.className = 'settings-item-row';

  const input = document.createElement('input');
  input.className = 'settings-item-name-input';
  input.value = initialValue;

  const save = document.createElement('button');
  save.className = 'btn-settings-save';
  save.textContent = 'Lưu';
  const doSave = () => onSave(input.value.trim());
  save.addEventListener('click', doSave);

  const cancel = document.createElement('button');
  cancel.className = 'btn-settings-cancel';
  cancel.textContent = 'Hủy';
  cancel.addEventListener('click', onCancel);

  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') doSave();
    else if (e.key === 'Escape') onCancel();
  });

  row.appendChild(input);
  row.appendChild(save);
  row.appendChild(cancel);
  // Focus after it's in the DOM.
  setTimeout(() => {
    input.focus();
    input.select();
  }, 0);
  return row;
}

function renderTagsPanel() {
  settingsContent.replaceChildren();
  settingsContent.appendChild(makeSettingsSectionTitle('Project tags'));

  settingsTags.forEach((tag, i) => {
    if (i === editingTagIndex) {
      settingsContent.appendChild(
        makeEditRow(
          tag,
          async (value) => {
            if (!value) return;
            settingsTags[i] = value;
            editingTagIndex = -1;
            await saveSettingsProjectTags(settingsTags);
            renderSettings();
            await commitSettings();
          },
          () => {
            editingTagIndex = -1;
            renderSettings();
          },
        ),
      );
      return;
    }

    const row = document.createElement('div');
    row.className = 'settings-item-row';

    const name = document.createElement('span');
    name.className = 'settings-item-name';
    name.textContent = tag;
    row.appendChild(name);

    const editBtn = document.createElement('button');
    editBtn.className = 'btn-settings-edit';
    editBtn.textContent = 'Sửa';
    editBtn.addEventListener('click', () => {
      editingTagIndex = i;
      addingTag = false;
      renderSettings();
    });
    row.appendChild(editBtn);

    const delBtn = document.createElement('button');
    delBtn.className = 'btn-settings-delete';
    delBtn.textContent = 'Xóa';
    delBtn.addEventListener('click', async () => {
      if (!confirm('Xóa tag này? Task đã dùng tag này sẽ không bị ảnh hưởng.')) return;
      settingsTags.splice(i, 1);
      if (editingTagIndex === i) editingTagIndex = -1;
      await saveSettingsProjectTags(settingsTags);
      renderSettings();
      await commitSettings();
    });
    row.appendChild(delBtn);

    settingsContent.appendChild(row);
  });

  if (addingTag) {
    settingsContent.appendChild(
      makeEditRow(
        '',
        async (value) => {
          if (!value) {
            addingTag = false;
            renderSettings();
            return;
          }
          if (!settingsTags.includes(value)) settingsTags.push(value);
          addingTag = false;
          await saveSettingsProjectTags(settingsTags);
          renderSettings();
          await commitSettings();
        },
        () => {
          addingTag = false;
          renderSettings();
        },
      ),
    );
  } else {
    settingsContent.appendChild(
      makeAddButton('Thêm tag mới', () => {
        addingTag = true;
        editingTagIndex = -1;
        renderSettings();
      }),
    );
  }
}

function renderTypesPanel() {
  settingsContent.replaceChildren();
  settingsContent.appendChild(makeSettingsSectionTitle('Loại công việc'));

  settingsTypesList.forEach((type, i) => {
    if (i === editingTypeIndex) {
      settingsContent.appendChild(
        makeEditRow(
          type.label,
          async (value) => {
            if (!value) return;
            // Keep the value (so existing tasks are unaffected); only relabel.
            settingsTypesList[i] = { ...type, label: value };
            editingTypeIndex = -1;
            await saveSettingsTaskTypes(settingsTypesList);
            renderSettings();
            await commitSettings();
          },
          () => {
            editingTypeIndex = -1;
            renderSettings();
          },
        ),
      );
      return;
    }

    const row = document.createElement('div');
    row.className = 'settings-item-row';

    const name = document.createElement('span');
    name.className = 'settings-item-name';
    name.textContent = type.label;
    row.appendChild(name);

    const editBtn = document.createElement('button');
    editBtn.className = 'btn-settings-edit';
    editBtn.textContent = 'Sửa';
    editBtn.addEventListener('click', () => {
      editingTypeIndex = i;
      addingType = false;
      renderSettings();
    });
    row.appendChild(editBtn);

    const delBtn = document.createElement('button');
    delBtn.className = 'btn-settings-delete';
    delBtn.textContent = 'Xóa';
    delBtn.addEventListener('click', async () => {
      const all = await getAllTasks();
      const usedCount = all.filter((t) => t.type === type.value).length;
      const msg = usedCount > 0
        ? `Loại này đang được dùng trong ${usedCount} task. Xóa khỏi danh sách nhưng các task cũ không bị ảnh hưởng.`
        : 'Xóa loại công việc này?';
      if (!confirm(msg)) return;
      settingsTypesList.splice(i, 1);
      if (editingTypeIndex === i) editingTypeIndex = -1;
      await saveSettingsTaskTypes(settingsTypesList);
      renderSettings();
      await commitSettings();
    });
    row.appendChild(delBtn);

    settingsContent.appendChild(row);
  });

  if (addingType) {
    settingsContent.appendChild(
      makeEditRow(
        '',
        async (value) => {
          if (!value) {
            addingType = false;
            renderSettings();
            return;
          }
          settingsTypesList.push({ value: slugifyType(value), label: value });
          addingType = false;
          await saveSettingsTaskTypes(settingsTypesList);
          renderSettings();
          await commitSettings();
        },
        () => {
          addingType = false;
          renderSettings();
        },
      ),
    );
  } else {
    settingsContent.appendChild(
      makeAddButton('Thêm loại mới', () => {
        addingType = true;
        editingTypeIndex = -1;
        renderSettings();
      }),
    );
  }
}

if (settingsBtn) settingsBtn.addEventListener('click', openSettings);
if (settingsNav) {
  settingsNav.addEventListener('click', (e) => {
    const item = e.target.closest('.settings-nav-item');
    if (!item) return;
    settingsPanel = item.dataset.panel;
    editingTagIndex = -1;
    addingTag = false;
    editingTypeIndex = -1;
    addingType = false;
    renderSettings();
  });
}
if (settingsOverlay) {
  settingsOverlay.addEventListener('click', (e) => {
    if (e.target === settingsOverlay || e.target.closest('#settings-close')) {
      closeSettings();
    }
  });
}
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && settingsOverlay && !settingsOverlay.hidden) closeSettings();
});

// --- Init ---

(async function init() {
  await loadData();
  onTasksChanged(loadData);
  renderIcons();
})();
