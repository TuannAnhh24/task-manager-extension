// Service worker.
// Note: done tasks are no longer auto-deleted — they are kept in storage so the
// History tab can show them, and are only removed when the user deletes them.
// (cleanOldDoneTasks still exists in storage.js but is intentionally not called.)

chrome.runtime.onInstalled.addListener(() => {
  // Nothing to do on install for now.
});
