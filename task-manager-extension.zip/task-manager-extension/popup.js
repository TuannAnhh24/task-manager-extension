// UI layer for the toolbar popup: renders the task list, quick-add bar and
// filter chips, and wires them to the storage.js data layer.
import {
  PRIORITY_ORDER,
  getVisibleTasks,
  createTask,
  updateTask,
  cycleTaskStatus,
  deleteTask,
  getProjectTags,
  getSettingsTaskTypes,
  onTasksChanged,
} from './storage.js';
import { createTagCombo } from './tag-combo.js';

/** Short "dd/MM" date, e.g. "02/07". */
function formatDateShort(isoString) {
  const date = new Date(isoString);
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  return `${day}/${month}`;
}

const PRIORITY_LABELS = {
  now: 'Làm ngay',
  schedule: 'Lên lịch',
  delegate: 'Tiện thì làm',
  drop: 'Có thể bỏ',
};

const PRIORITY_COLOR_VAR = {
  now: '--priority-now',
  schedule: '--priority-schedule',
  delegate: '--priority-delegate',
  drop: '--priority-drop',
};

// Task types are configured in Settings (fullpage); the popup only reads them
// to label badges. Look up label by value, falling back to the raw value.
let taskTypes = [];
function typeLabel(value) {
  const match = taskTypes.find((t) => t.value === value);
  return match ? match.label : value;
}

let allTasks = [];
let projectTags = [];
let activeTagFilter = 'all';
let quickAddPriority = 'now';

const listEl = document.getElementById('task-list');
const chipsEl = document.getElementById('filter-chips');
const quickAddInput = document.getElementById('quick-add-input');
const quickAddExtra = document.getElementById('quick-add-extra');
const quickAddNote = document.getElementById('quick-add-note');
const quickAddTagComboEl = document.getElementById('quick-add-tag-combo');
const quickAddSubmit = document.getElementById('quick-add-submit');
const quickAddPriorities = document.getElementById('quick-add-priorities');
const captureUrlBtn = document.getElementById('btn-capture-url');
const tooltipEl = document.getElementById('quick-add-tooltip');
const openFullpageBtn = document.getElementById('open-fullpage');

let tooltipTimer = null;
function showTooltip(message) {
  tooltipEl.textContent = message;
  tooltipEl.hidden = false;
  clearTimeout(tooltipTimer);
  tooltipTimer = setTimeout(() => {
    tooltipEl.hidden = true;
  }, 2000);
}

const quickAddTagCombo = createTagCombo({
  container: quickAddTagComboEl,
  getTags: () => projectTags,
  onChange: () => {},
  openUp: true,
});

function renderIcons() {
  if (window.lucide) window.lucide.createIcons();
}

async function loadData() {
  const [tasks, tags, types] = await Promise.all([
    getVisibleTasks(),
    getProjectTags(),
    getSettingsTaskTypes(),
  ]);
  allTasks = tasks;
  projectTags = tags;
  taskTypes = types;
  renderFilterChips();
  renderTaskList();
}

function renderFilterChips() {
  chipsEl.replaceChildren();

  const allChip = document.createElement('button');
  allChip.className = 'chip' + (activeTagFilter === 'all' ? ' is-active' : '');
  allChip.textContent = 'Tất cả';
  allChip.addEventListener('click', () => {
    activeTagFilter = 'all';
    renderFilterChips();
    renderTaskList();
  });
  chipsEl.appendChild(allChip);

  for (const tag of projectTags) {
    const chip = document.createElement('button');
    chip.className = 'chip' + (activeTagFilter === tag ? ' is-active' : '');
    chip.textContent = tag;
    chip.addEventListener('click', () => {
      activeTagFilter = tag;
      renderFilterChips();
      renderTaskList();
    });
    chipsEl.appendChild(chip);
  }
}

function filteredTasks() {
  if (activeTagFilter === 'all') return allTasks;
  return allTasks.filter((task) => task.project_tag === activeTagFilter);
}

function makeCheckIconSvg() {
  const svgNS = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(svgNS, 'svg');
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('fill', 'none');
  svg.setAttribute('stroke', 'currentColor');
  svg.setAttribute('stroke-width', '3');
  svg.setAttribute('stroke-linecap', 'round');
  svg.setAttribute('stroke-linejoin', 'round');
  const path = document.createElementNS(svgNS, 'path');
  path.setAttribute('d', 'M20 6 9 17l-5-5');
  svg.appendChild(path);
  return svg;
}

function makeCheckbox(task) {
  const checkbox = document.createElement('button');
  let cls = 'checkbox';
  if (task.status === 'done') cls += ' is-checked';
  else if (task.status === 'in_progress') cls += ' is-progress';
  checkbox.className = cls;
  checkbox.setAttribute('aria-label', 'Đổi trạng thái task');
  if (task.status === 'done') {
    // When checked, tint the box with the task's own priority color.
    const color = `var(${PRIORITY_COLOR_VAR[task.priority]})`;
    checkbox.style.background = color;
    checkbox.style.borderColor = color;
  }
  checkbox.appendChild(makeCheckIconSvg());
  checkbox.addEventListener('click', async () => {
    // Cycle: todo -> in_progress -> done -> todo.
    await cycleTaskStatus(task.id);
    await loadData();
  });
  return checkbox;
}

function makeMetaDot() {
  const dot = document.createElement('span');
  dot.className = 'meta-dot';
  dot.textContent = '•';
  return dot;
}

// Swap the title <div> for an <input> so the task can be renamed inline.
function startInlineEdit(titleEl, task) {
  const input = document.createElement('input');
  input.type = 'text';
  input.className = 'task-title task-title--editing';
  input.value = task.title;
  titleEl.replaceWith(input);
  input.focus();
  input.select();

  let committed = false;
  const commit = async () => {
    if (committed) return;
    committed = true;
    const newTitle = input.value.trim();
    if (newTitle && newTitle !== task.title) {
      await updateTask(task.id, { title: newTitle });
      await loadData();
    } else {
      input.replaceWith(titleEl);
    }
  };
  input.addEventListener('blur', commit);
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      input.blur();
    } else if (e.key === 'Escape') {
      committed = true;
      input.replaceWith(titleEl);
    }
  });
}

function buildTaskRow(task) {
  const row = document.createElement('div');
  row.className = 'task-row' + (task.status === 'done' ? ' done' : '');
  row.dataset.id = task.id;

  row.appendChild(makeCheckbox(task));

  const body = document.createElement('div');
  body.className = 'task-body';

  const title = document.createElement('div');
  title.className = 'task-title';
  title.textContent = task.title;
  if (task.note) title.title = task.note;
  title.addEventListener('click', (e) => {
    e.stopPropagation();
    startInlineEdit(title, task);
  });
  body.appendChild(title);

  const meta = document.createElement('div');
  meta.className = 'task-meta';

  if (task.status === 'in_progress') {
    const progressBadge = document.createElement('span');
    progressBadge.className = 'meta-inprogress';
    progressBadge.textContent = 'Đang làm';
    meta.appendChild(progressBadge);
  }

  const typeBadge = document.createElement('span');
  typeBadge.className = 'meta-badge';
  typeBadge.textContent = typeLabel(task.type);
  meta.appendChild(typeBadge);

  if (task.project_tag) {
    meta.appendChild(makeMetaDot());
    const tag = document.createElement('span');
    tag.className = 'meta-tag';
    tag.textContent = task.project_tag;
    meta.appendChild(tag);
  }

  meta.appendChild(makeMetaDot());
  const date = document.createElement('span');
  date.className = 'meta-date';
  date.textContent = formatDateShort(task.created_at);
  meta.appendChild(date);

  body.appendChild(meta);
  row.appendChild(body);

  const deleteBtn = document.createElement('button');
  deleteBtn.className = 'icon-btn task-del';
  deleteBtn.setAttribute('aria-label', 'Xóa task');
  const deleteIcon = document.createElement('i');
  deleteIcon.setAttribute('data-lucide', 'trash-2');
  deleteBtn.appendChild(deleteIcon);
  deleteBtn.addEventListener('click', async (e) => {
    e.stopPropagation();
    await deleteTask(task.id);
    await loadData();
  });
  row.appendChild(deleteBtn);

  return row;
}

function buildListEmptyState() {
  const wrap = document.createElement('div');
  wrap.className = 'list-empty';

  const icon = document.createElement('i');
  icon.setAttribute('data-lucide', 'clipboard-list');
  icon.className = 'list-empty__icon';
  wrap.appendChild(icon);

  const line1 = document.createElement('div');
  line1.className = 'list-empty__title';
  line1.textContent = 'Chưa có task nào';
  wrap.appendChild(line1);

  const line2 = document.createElement('div');
  line2.className = 'list-empty__hint';
  line2.textContent = 'Thêm task đầu tiên bên dưới';
  wrap.appendChild(line2);

  return wrap;
}

function buildGroupEmptyState() {
  const wrap = document.createElement('div');
  wrap.className = 'group-empty';

  const icon = document.createElement('i');
  icon.setAttribute('data-lucide', 'minus');
  icon.className = 'group-empty__icon';
  wrap.appendChild(icon);

  const text = document.createElement('span');
  text.textContent = 'Không có task nào';
  wrap.appendChild(text);

  return wrap;
}

function renderTaskList() {
  listEl.replaceChildren();
  const tasks = filteredTasks();

  // No tasks at all (or filter yields nothing): show one centered empty state
  // instead of four empty priority groups stacked on top of each other.
  if (tasks.length === 0) {
    listEl.appendChild(buildListEmptyState());
    renderIcons();
    return;
  }

  for (const priority of PRIORITY_ORDER) {
    const doneRank = (t) => (t.status === 'done' ? 1 : 0);
    const group = tasks
      .filter((task) => task.priority === priority)
      .sort((a, b) => doneRank(a) - doneRank(b));

    const header = document.createElement('div');
    header.className = 'task-group__header';
    header.style.color = `var(${PRIORITY_COLOR_VAR[priority]})`;
    const dot = document.createElement('span');
    dot.className = 'task-group__dot';
    dot.style.background = `var(${PRIORITY_COLOR_VAR[priority]})`;
    header.appendChild(dot);
    const label = document.createElement('span');
    label.className = 'task-group__label';
    label.textContent = PRIORITY_LABELS[priority];
    header.appendChild(label);
    const rule = document.createElement('span');
    rule.className = 'task-group__rule';
    header.appendChild(rule);
    listEl.appendChild(header);

    if (group.length === 0) {
      listEl.appendChild(buildGroupEmptyState());
      continue;
    }

    for (const task of group) {
      listEl.appendChild(buildTaskRow(task));
    }
  }

  renderIcons();
}

// --- Quick add bar ---

quickAddInput.addEventListener('focus', () => {
  quickAddExtra.hidden = false;
});

quickAddPriorities.addEventListener('click', (e) => {
  const btn = e.target.closest('[data-priority]');
  if (!btn) return;
  quickAddPriority = btn.dataset.priority;
  for (const pill of quickAddPriorities.querySelectorAll('.priority-pill')) {
    pill.classList.toggle('is-active', pill === btn);
  }
});

async function submitQuickAdd() {
  const title = quickAddInput.value.trim();
  if (!title) return;
  await createTask({
    title,
    note: quickAddNote.value.trim(),
    priority: quickAddPriority,
    type: 'other',
    project_tag: quickAddTagCombo.getValue(),
  });
  quickAddInput.value = '';
  quickAddNote.value = '';
  quickAddTagCombo.setValue('');
  quickAddExtra.hidden = true;
  await loadData();
}

quickAddInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') submitQuickAdd();
});
quickAddSubmit.addEventListener('click', submitQuickAdd);

captureUrlBtn.addEventListener('click', async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.url && !tab.url.startsWith('chrome://') && !tab.url.startsWith('chrome-extension://')) {
      quickAddExtra.hidden = false;
      quickAddNote.value = `${tab.title} — ${tab.url}`;
      quickAddInput.focus();
      showTooltip('Đã thêm URL trang hiện tại vào ghi chú');
    } else {
      showTooltip('Không thể lấy URL từ trang này');
    }
  } catch (err) {
    console.error('[TaskManager] capture URL failed', err);
    showTooltip('Không thể lấy URL từ trang này');
  }
});

openFullpageBtn.addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('fullpage.html') });
});

// --- Init ---

(async function init() {
  await loadData();
  onTasksChanged(loadData);
  renderIcons();
})();
