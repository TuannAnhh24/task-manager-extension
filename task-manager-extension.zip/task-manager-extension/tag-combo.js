// Reusable "select existing tag or type a new one" combo box.
// Shared by the popup quick-add bar and the fullpage edit panel so the
// project_tag field is never a bare free-typing <input>.

function svgIcon(name) {
  const i = document.createElement('i');
  i.setAttribute('data-lucide', name);
  return i;
}

function renderIcons() {
  if (window.lucide) window.lucide.createIcons();
}

/**
 * @param {HTMLElement} container - empty element to mount the combo into
 * @param {() => string[]} getTags - returns the current list of known tags
 * @param {(value: string) => void} onChange - called whenever the value changes
 * @param {string} [initialValue]
 */
export function createTagCombo({ container, getTags, onChange, initialValue = '', openUp = false }) {
  let value = initialValue;
  let open = false;

  container.classList.add('tag-combo');
  container.replaceChildren();

  const control = document.createElement('div');
  control.className = 'tag-combo__control';
  control.appendChild(svgIcon('tag'));

  const input = document.createElement('input');
  input.type = 'text';
  input.className = 'tag-combo__input';
  input.placeholder = 'Project tag...';
  // "Project tag" kept in English intentionally.
  input.autocomplete = 'off';
  input.value = value;
  control.appendChild(input);

  const clearBtn = document.createElement('button');
  clearBtn.type = 'button';
  clearBtn.className = 'tag-combo__clear';
  clearBtn.setAttribute('aria-label', 'Bỏ chọn tag');
  clearBtn.appendChild(svgIcon('x'));
  clearBtn.hidden = value.length === 0;
  control.appendChild(clearBtn);

  control.appendChild(svgIcon('chevron-down'));

  const dropdown = document.createElement('div');
  dropdown.className = 'tag-combo__dropdown';
  // In the popup the combo sits at the bottom of the window, so the list must
  // open upward or it renders off-screen behind the popup's clipped edge.
  if (openUp) dropdown.classList.add('tag-combo__dropdown--up');
  dropdown.hidden = true;

  container.appendChild(control);
  container.appendChild(dropdown);

  function setValue(newValue) {
    value = newValue || '';
    input.value = value;
    clearBtn.hidden = value.length === 0;
  }

  function commit(newValue) {
    setValue(newValue);
    onChange(value);
  }

  function closeDropdown() {
    open = false;
    dropdown.hidden = true;
    dropdown.replaceChildren();
  }

  function renderDropdown() {
    dropdown.replaceChildren();
    const query = input.value.trim().toLowerCase();
    const tags = getTags();
    const matches = query ? tags.filter((tag) => tag.toLowerCase().includes(query)) : tags;

    if (tags.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'tag-combo__empty';
      empty.textContent = 'Chưa có tag nào. Gõ để tạo mới.';
      dropdown.appendChild(empty);
    } else {
      for (const tag of matches) {
        const option = document.createElement('button');
        option.type = 'button';
        option.className = 'tag-combo__option';
        option.textContent = tag;
        option.addEventListener('mousedown', (e) => {
          e.preventDefault();
          commit(tag);
          closeDropdown();
        });
        dropdown.appendChild(option);
      }
    }

    const trimmed = input.value.trim();
    const exactMatch = tags.some((tag) => tag.toLowerCase() === trimmed.toLowerCase());
    if (trimmed && !exactMatch) {
      const divider = document.createElement('div');
      divider.className = 'tag-combo__divider';
      dropdown.appendChild(divider);

      const createOption = document.createElement('button');
      createOption.type = 'button';
      createOption.className = 'tag-combo__option tag-combo__option--create';
      createOption.textContent = `+ Tạo tag mới: "${trimmed}"`;
      createOption.addEventListener('mousedown', (e) => {
        e.preventDefault();
        commit(trimmed);
        closeDropdown();
      });
      dropdown.appendChild(createOption);
    }
  }

  function openDropdown() {
    open = true;
    dropdown.hidden = false;
    renderDropdown();
    renderIcons();
  }

  function commitFromInput() {
    const trimmed = input.value.trim();
    if (trimmed !== value) commit(trimmed);
  }

  // Clicking anywhere on the control (chevron, tag icon, blank area) toggles the
  // dropdown — not just focusing the <input> directly.
  control.addEventListener('mousedown', (e) => {
    if (e.target === input || clearBtn.contains(e.target)) return;
    e.preventDefault();
    if (open) closeDropdown();
    else input.focus();
  });

  input.addEventListener('focus', openDropdown);
  input.addEventListener('input', () => {
    if (!open) openDropdown();
    else renderDropdown();
  });
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      commitFromInput();
      closeDropdown();
      input.blur();
    } else if (e.key === 'Escape') {
      closeDropdown();
      input.blur();
    }
  });
  input.addEventListener('blur', commitFromInput);

  clearBtn.addEventListener('click', () => {
    commit('');
    input.focus();
  });

  document.addEventListener('click', (e) => {
    if (open && !container.contains(e.target)) closeDropdown();
  });

  renderIcons();

  return {
    getValue: () => value,
    setValue,
  };
}
