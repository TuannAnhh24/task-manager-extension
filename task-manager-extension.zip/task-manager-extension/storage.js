// Data layer: all chrome.storage.sync CRUD for tasks lives here.
// Tasks are stored as individual keys (`task_<id>`) rather than one array,
// to stay under the 8KB per-item quota that chrome.storage.sync enforces.

const TASK_KEY_PREFIX = 'task_';
const PRIORITY_ORDER = ['now', 'schedule', 'delegate', 'drop'];

// Suggested project tags that are always offered, even before any task uses them.
const DEFAULT_PROJECT_TAGS = [
  'humipro.vn',
  'daotao.humipro.vn',
  'humi.vn',
  'web-moi',
  'Fanpage',
  'YouTube',
  'TikTok',
  'Team Media',
  'Vận hành',
  'Cá nhân',
];

// Default task types (value + display label). Editable via Settings.
const DEFAULT_TASK_TYPES = [
  { value: 'bug', label: 'Bug fix' },
  { value: 'feature', label: 'Dev / Feature' },
  { value: 'content', label: 'Nội dung' },
  { value: 'manage', label: 'Quản lý' },
  { value: 'operation', label: 'Vận hành' },
  { value: 'other', label: 'Khác' },
];

const SETTINGS_TAGS_KEY = 'settings_project_tags';
const SETTINGS_TYPES_KEY = 'settings_task_types';

function taskKey(id) {
  return `${TASK_KEY_PREFIX}${id}`;
}

function generateId() {
  if (crypto.randomUUID) return crypto.randomUUID();
  // Fallback UUID v4 for environments without crypto.randomUUID.
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

function startOfToday() {
  return new Date().setHours(0, 0, 0, 0);
}

function sortTasks(tasks) {
  return tasks.slice().sort((a, b) => {
    const pa = PRIORITY_ORDER.indexOf(a.priority);
    const pb = PRIORITY_ORDER.indexOf(b.priority);
    if (pa !== pb) return pa - pb;
    if (a.order !== b.order) return a.order - b.order;
    return new Date(b.created_at) - new Date(a.created_at);
  });
}

/** Fetch every task stored, regardless of status. */
async function getAllTasks() {
  try {
    const all = await chrome.storage.sync.get(null);
    const tasks = Object.keys(all)
      .filter((key) => key.startsWith(TASK_KEY_PREFIX))
      .map((key) => all[key]);
    return sortTasks(tasks);
  } catch (err) {
    console.error('[TaskManager] getAllTasks failed', err);
    return [];
  }
}

/** Tasks that should be shown in the UI: not-done, or done earlier today. */
async function getVisibleTasks() {
  const all = await getAllTasks();
  const todayStart = startOfToday();
  return all.filter((task) => {
    if (task.status !== 'done') return true;
    return task.done_at !== null && task.done_at >= todayStart;
  });
}

/** Fetch a single task by id, or null if it no longer exists. */
async function getTaskById(id) {
  try {
    const key = taskKey(id);
    const existing = await chrome.storage.sync.get(key);
    return existing[key] || null;
  } catch (err) {
    console.error('[TaskManager] getTaskById failed', err);
    return null;
  }
}

/** Create a new task and persist it. Returns the created task object. */
async function createTask({ title, note = '', priority = 'now', type = 'other', project_tag = '' }) {
  const task = {
    id: generateId(),
    title,
    note,
    priority,
    type,
    project_tag,
    status: 'todo',
    done_at: null,
    order: 0,
    created_at: new Date().toISOString(),
  };
  try {
    await chrome.storage.sync.set({ [taskKey(task.id)]: task });
    return task;
  } catch (err) {
    console.error('[TaskManager] createTask failed', err);
    throw err;
  }
}

/** Apply a partial update to an existing task. */
async function updateTask(id, changes) {
  try {
    const key = taskKey(id);
    const existing = await chrome.storage.sync.get(key);
    const current = existing[key];
    if (!current) {
      console.error('[TaskManager] updateTask: task not found', id);
      return null;
    }
    const updated = { ...current, ...changes };
    await chrome.storage.sync.set({ [key]: updated });
    return updated;
  } catch (err) {
    console.error('[TaskManager] updateTask failed', err);
    throw err;
  }
}

/** Advance a task through the status cycle: todo -> in_progress -> done -> todo. */
async function cycleTaskStatus(id) {
  const task = await getTaskById(id);
  if (!task) return null;
  const nextStatus = {
    todo: 'in_progress',
    in_progress: 'done',
    done: 'todo',
  };
  const next = nextStatus[task.status] || 'in_progress';
  return updateTask(id, {
    status: next,
    done_at: next === 'done' ? Date.now() : null,
  });
}

/** Tasks completed today, most recently finished first (for the "Today" tab). */
async function getTodayDoneTasks() {
  const all = await getAllTasks();
  const todayStart = startOfToday();
  return all
    .filter((task) => task.status === 'done' && task.done_at !== null && task.done_at >= todayStart)
    .sort((a, b) => b.done_at - a.done_at);
}

/** Every completed task, most recently finished first (for the "History" tab). */
async function getAllDoneTasks() {
  const all = await getAllTasks();
  return all
    .filter((task) => task.status === 'done')
    .sort((a, b) => (b.done_at || 0) - (a.done_at || 0));
}

/** Permanently remove a task. */
async function deleteTask(id) {
  try {
    await chrome.storage.sync.remove(taskKey(id));
  } catch (err) {
    console.error('[TaskManager] deleteTask failed', err);
    throw err;
  }
}

/** Persist a new manual ordering for the todo tasks within one priority group. */
async function reorderTasks(priorityGroup, orderedIds) {
  try {
    const updates = {};
    orderedIds.forEach((id, index) => {
      updates[id] = index;
    });
    const keys = orderedIds.map(taskKey);
    const existing = await chrome.storage.sync.get(keys);
    const writes = {};
    for (const id of orderedIds) {
      const key = taskKey(id);
      const task = existing[key];
      if (!task || task.priority !== priorityGroup) continue;
      writes[key] = { ...task, order: updates[id] };
    }
    if (Object.keys(writes).length) {
      await chrome.storage.sync.set(writes);
    }
  } catch (err) {
    console.error('[TaskManager] reorderTasks failed', err);
    throw err;
  }
}

/** Project tags configured in Settings (falls back to defaults). */
async function getSettingsProjectTags() {
  try {
    const result = await chrome.storage.sync.get(SETTINGS_TAGS_KEY);
    return result[SETTINGS_TAGS_KEY] || DEFAULT_PROJECT_TAGS;
  } catch (err) {
    console.error('[TaskManager] getSettingsProjectTags failed', err);
    return DEFAULT_PROJECT_TAGS;
  }
}

/** Persist the Settings project-tag list. */
async function saveSettingsProjectTags(tags) {
  try {
    await chrome.storage.sync.set({ [SETTINGS_TAGS_KEY]: tags });
  } catch (err) {
    console.error('[TaskManager] saveSettingsProjectTags failed', err);
    throw err;
  }
}

/** Task types configured in Settings (falls back to defaults). */
async function getSettingsTaskTypes() {
  try {
    const result = await chrome.storage.sync.get(SETTINGS_TYPES_KEY);
    const stored = result[SETTINGS_TYPES_KEY];
    return Array.isArray(stored) && stored.length ? stored : DEFAULT_TASK_TYPES;
  } catch (err) {
    console.error('[TaskManager] getSettingsTaskTypes failed', err);
    return DEFAULT_TASK_TYPES;
  }
}

/** Persist the Settings task-type list. */
async function saveSettingsTaskTypes(types) {
  try {
    await chrome.storage.sync.set({ [SETTINGS_TYPES_KEY]: types });
  } catch (err) {
    console.error('[TaskManager] saveSettingsTaskTypes failed', err);
    throw err;
  }
}

/** Settings tags merged with any tags already used in tasks (settings first). */
async function getProjectTags() {
  const settingsTags = await getSettingsProjectTags();
  const all = await getAllTasks();
  const usedTags = [...new Set(all.map((t) => t.project_tag).filter(Boolean))];
  return [...new Set([...settingsTags, ...usedTags])];
}

/** Hard-delete any "done" task whose done_at falls before today. */
async function cleanOldDoneTasks() {
  try {
    const all = await getAllTasks();
    const todayStart = startOfToday();
    const staleIds = all
      .filter((task) => task.status === 'done' && task.done_at !== null && task.done_at < todayStart)
      .map((task) => taskKey(task.id));
    if (staleIds.length) {
      await chrome.storage.sync.remove(staleIds);
    }
    return staleIds.length;
  } catch (err) {
    console.error('[TaskManager] cleanOldDoneTasks failed', err);
    return 0;
  }
}

/** Current chrome.storage.sync usage vs the 100KB quota. */
async function getStorageUsage() {
  return new Promise((resolve) => {
    chrome.storage.sync.getBytesInUse(null, (bytesInUse) => {
      const totalBytes = chrome.storage.sync.QUOTA_BYTES; // 102400 = 100KB
      const usedKB = (bytesInUse / 1024).toFixed(1);
      const totalKB = (totalBytes / 1024).toFixed(0);
      const percent = Math.round((bytesInUse / totalBytes) * 100);
      resolve({ bytesInUse, totalBytes, usedKB, totalKB, percent });
    });
  });
}

/** Subscribe to live changes so open popup/fullpage views can re-render. */
function onTasksChanged(callback) {
  const listener = (changes, areaName) => {
    if (areaName !== 'sync') return;
    const relevant = Object.keys(changes).some(
      (key) => key.startsWith(TASK_KEY_PREFIX) || key === SETTINGS_TAGS_KEY || key === SETTINGS_TYPES_KEY,
    );
    if (relevant) callback();
  };
  chrome.storage.onChanged.addListener(listener);
  return () => chrome.storage.onChanged.removeListener(listener);
}

export {
  PRIORITY_ORDER,
  DEFAULT_TASK_TYPES,
  getAllTasks,
  getVisibleTasks,
  getTaskById,
  createTask,
  updateTask,
  cycleTaskStatus,
  getTodayDoneTasks,
  getAllDoneTasks,
  deleteTask,
  reorderTasks,
  getProjectTags,
  getSettingsProjectTags,
  saveSettingsProjectTags,
  getSettingsTaskTypes,
  saveSettingsTaskTypes,
  getStorageUsage,
  cleanOldDoneTasks,
  onTasksChanged,
};
